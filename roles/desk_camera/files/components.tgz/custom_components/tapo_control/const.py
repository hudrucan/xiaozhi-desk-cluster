import logging
import voluptuous as vol

from datetime import timedelta

from homeassistant.helpers import config_validation as cv

# Used for conflict detection
TPLINK_DOMAIN = "tplink"

CONTROL_PORT = "control_port"
PYTAPO_REQUIRED_VERSION = "3.4.26"
DOMAIN = "tapo_control"
DOMAIN_CONFIG = DOMAIN + "_config"
BRAND = "TP-Link"
DOORBELL_UDP_PORT = 20005
DOORBELL_UDP_DISCOVERED = "doorbell_udp_discovered"
ALARM_MODE = "alarm_mode"
PRESET = "preset"
LIGHT = "light"
SOUND = "sound"
PRIVACY_MODE = "privacy_mode"
ALARM = "alarm"
LED_MODE = "led_mode"
NAME = "name"
DISTANCE = "distance"
TILT = "tilt"
PAN = "pan"
MOTION_DETECTION_MODE = "motion_detection_mode"
AUTO_TRACK_MODE = "auto_track_mode"
CLOUD_USERNAME = "cloud_username"
CLOUD_PASSWORD = "cloud_password"
DEFAULT_SCAN_INTERVAL = 10
SCAN_INTERVAL = timedelta(seconds=5)
CONF_CUSTOM_STREAM_HD = "custom_stream_hd"
CONF_CUSTOM_STREAM_SD = "custom_stream_sd"
CONF_CUSTOM_STREAM_6 = "custom_stream6"
CONF_CUSTOM_STREAM_7 = "custom_stream7"
CONF_DIRECT_STREAM_ARGUMENTS = "direct_stream_arguments"
CONF_SHOW_ON_MAP = "show_on_map"
# Arguments supported by pytapo Streamer when audio is disabled.
DIRECT_STREAM_ARGUMENTS = (
    "-loglevel",
    "-probesize",
    "-analyzeduration",
    "-frames:v",
    "-map-video",
    "-vsync",
    "-c:v",
    "-f",
)
CONF_SKIP_RTSP = "skip_rtsp"
CONF_TRANSPORT_METHOD = "transport_method"

ENABLE_MOTION_SENSOR = "enable_motion_sensor"
ENABLE_MEDIA_SYNC = "enable_media_sync"

IS_KLAP_DEVICE = "is_klap_device"
REPORTED_IP_ADDRESS = "reported_ip_address"
UPDATE_INTERVAL_MAIN = "update_interval_main"
UPDATE_INTERVAL_BATTERY = "update_interval_battery"
UPDATE_INTERVAL_MAIN_DEFAULT = 30
UPDATE_INTERVAL_BATTERY_DEFAULT = 60 * 10

TIME_SYNC_DST = "time_sync_dst"
TIME_SYNC_NDST = "time_sync_ndst"
TIME_SYNC_DST_DEFAULT = 1
TIME_SYNC_NDST_DEFAULT = 0

MEDIA_VIEW_DAYS_ORDER = "media_view_days_order"
MEDIA_VIEW_RECORDINGS_ORDER = "media_view_recordings_order"
MEDIA_SYNC_HOURS = "media_sync_hours"
MEDIA_SYNC_COLD_STORAGE_PATH = "media_sync_cold_storage_path"
MEDIA_SYNC_PREVIOUS_STORAGE_PATH = "media_sync_previous_storage_path"
MEDIA_THUMBNAIL_CACHE = "media_thumbnail_cache"
MEDIA_THUMBNAIL_PRELOAD = "media_thumbnail_preload"
THUMBNAIL_CACHE_SECONDS = 5 * 60

TOGGLE_STATES = ["on", "off"]

CONF_RTSP_TRANSPORT = "rtsp_transport"
RTSP_TRANS_PROTOCOLS = ["tcp", "udp", "udp_multicast", "http"]
MEDIA_VIEW_DAYS_ORDER_OPTIONS = ["Ascending", "Descending"]
MEDIA_VIEW_RECORDINGS_ORDER_OPTIONS = ["Ascending", "Descending"]

ENABLE_WEBHOOKS = "enable_webhooks"
ENABLE_STREAM = "enable_stream"
ENABLE_SOUND_DETECTION = "enable_sound_detection"
SOUND_DETECTION_PEAK = "sound_detection_peak"
SOUND_DETECTION_DURATION = "sound_detection_duration"
SOUND_DETECTION_RESET = "sound_detection_reset"

ENABLE_TIME_SYNC = "enable_time_sync"
HAS_STREAM_6 = "has_stream6"
HAS_STREAM_7 = "has_stream7"

LOGGER = logging.getLogger("custom_components." + DOMAIN)

TIME_SYNC_PERIOD = 3600
RECORDINGS_UNAVAILABLE_MESSAGE = (
    "Recordings are unavailable. Insert an SD card into the camera and try again."
)
MEDIA_CLEANUP_PERIOD = 10 * 60
UPDATE_CHECK_PERIOD = 86400

COLD_DIR_DELETE_TIME = 24 * 60 * 60
HOT_DIR_DELETE_TIME = 60 * 60

MEDIA_SYNC_WATCHDOG_SECONDS = 5 * 60

SERVICE_SAVE_PRESET = "save_preset"
SCHEMA_SERVICE_SAVE_PRESET = {
    vol.Required(NAME): cv.string,
}

SERVICE_DELETE_PRESET = "delete_preset"
SCHEMA_SERVICE_DELETE_PRESET = {
    vol.Required(PRESET): cv.string,
}


def _validate_record_plan_period(value):
    """Validate a same-day recording period in pytapo's HHMM-HHMM:mode format."""
    value = vol.All(
        str,
        vol.Match(
            r"^(?:[01][0-9]|2[0-3])[0-5][0-9]-"
            r"(?:(?:[01][0-9]|2[0-3])[0-5][0-9]|2400):[12]\Z"
        ),
    )(value)
    if value[:4] >= value[5:9]:
        raise vol.Invalid("Recording period must end after it starts")
    return value


SERVICE_SET_RECORD_PLAN = "set_record_plan"
SCHEMA_SERVICE_SET_RECORD_PLAN = {
    vol.Required("enabled"): cv.boolean,
    **{
        vol.Optional(day): [_validate_record_plan_period]
        for day in (
            "sunday",
            "monday",
            "tuesday",
            "wednesday",
            "thursday",
            "friday",
            "saturday",
        )
    },
}


TAPO_PREFIXES = (
    r"^c[0-9]{3}[a-zA-Z]*_.*",  # Security Cameras (C100, C200, C310, C325WB, etc.)
    r"^d[0-9]{3}[a-zA-Z]*_.*",  # Doorbells (D230, D235, D350V, etc.)
    r"^tc[0-9]{2,3}[a-zA-Z]*_.*",  # Pan/Tilt Cameras (TC60, TC70, TC85, etc.)
    r"^d[0-9]{3}[a-zA-Z]*c_.*",  # Doorbell Chimes (D100C, D230C, D325C, etc.)
    r"^h[0-9]{3}[a-zA-Z]*_.*",  # Smart Hubs (H100, H200, H300, etc.)
)
